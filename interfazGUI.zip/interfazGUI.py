import tkinter as tk
from tkinter import font
from tkinter import PhotoImage
from PIL import Image, ImageTk
import subprocess

# Funciones para los botones
def posicion_de_pie():
    subprocess.Popen(["python", "posPie.py"])

def posicion_de_arrodillado():
    subprocess.Popen(["python", "posRod.py"])

# Función para salir del modo pantalla completa
def salir_fullscreen(event):
    root.attributes('-fullscreen', False)

# Crear la ventana principal
root = tk.Tk()
root.title("SIET-4D")
root.attributes('-fullscreen', True)  # Pantalla completa
root.bind("<Escape>", salir_fullscreen)  # Vincular la tecla Esc para salir del modo pantalla completa

# Colores
bg_color = "#0000FF"  # Azul
fg_color = "#FFFF00"  # Amarillo
background_color = "#FFFACD"  # Amarillo pastel

# Configurar el fondo de la ventana
root.configure(bg=background_color)

# Crear una fuente grande para la etiqueta
label_font = font.Font(family="Helvetica", size=32, weight="bold")

# Crear un marco para centrar el contenido
frame = tk.Frame(root, bg=background_color)
frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

# Crear una etiqueta grande
label = tk.Label(frame, text="Bienvenido al Sistema de Reconocimiento de Posiciones", 
                 font=label_font, fg=bg_color, bg=background_color, wraplength=700)
label.pack(pady=20)

# Cargar y redimensionar la imagen usando PIL
image_path = "imagen1.png"
original_image = Image.open(image_path)
resized_image = original_image.resize((500, 400))  # Cambia el tamaño de la imagen (ancho, alto)
imagen = ImageTk.PhotoImage(resized_image)

# Crear un widget Label para mostrar la imagen
image_label = tk.Label(frame, image=imagen, bg=background_color)
image_label.pack(pady=10)

# Crear los botones
btn_pie = tk.Button(frame, text="Posición de Pie", command=posicion_de_pie, 
                    bg=bg_color, fg=fg_color, font=label_font, width=20)
btn_pie.pack(pady=10)

btn_arrodillado = tk.Button(frame, text="Posición de Rodilla", command=posicion_de_arrodillado, 
                            bg=bg_color, fg=fg_color, font=label_font, width=20)
btn_arrodillado.pack(pady=10)

# Ejecutar el bucle principal
root.mainloop()
